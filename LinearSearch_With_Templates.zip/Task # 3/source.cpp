#include "MyLinearSearch.h"
#include<iostream>
#include<string>
using namespace std;

int main() 
{
    int intArray[5] = { 64, 25, 12, 22, 11 };
    int intKey = 25;
    int intIndex = linearSearch(intArray, 5, intKey);
    printSearchResult(intIndex, intKey);

    float floatArray[4] = { 3.14, 2.71, 1.62, 0.57 };
    float floatKey = 0.57;
    int floatIndex = linearSearch(floatArray, 4, floatKey);
    printSearchResult(floatIndex, floatKey);

    string stringArray[4] = { "Apple", "Orange", "Banana", "Grape" };
    string stringKey = "Banana";
    int stringIndex = linearSearch(stringArray, 4, stringKey);
    printSearchResult(stringIndex, stringKey);




    return 0;
}

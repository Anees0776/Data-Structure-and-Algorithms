#pragma once
#include <iostream>
using namespace std;

template <class T>
int linearSearch(const T arr[], int size, T value);

template <class T>
void printSearchResult(int index, T value);


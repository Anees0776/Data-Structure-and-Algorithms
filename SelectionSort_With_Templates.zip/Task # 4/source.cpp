#include "MyBinarySearch.h"
#include <iostream>
#include<string>
using namespace std;

int main() 
{
    int intArray[5] = { 11, 12, 22, 25, 64 };
    int intKey = 22;
    int intIndex = binarySearch(intArray, 5, intKey);
    printSearchResult(intIndex, intKey);

    float floatArray[4] = { 0.57, 1.62, 2.71, 3.14 };
    float floatKey = 2.71;
    int floatIndex = binarySearch(floatArray, 4, floatKey);
    printSearchResult(floatIndex, floatKey);

    string stringArray[4] = { "Apple", "Banana", "Grape", "Orange" };
    string stringKey = "Grape";
    int stringIndex = binarySearch(stringArray, 4, stringKey);
    printSearchResult(stringIndex, stringKey);



    return 0;
}

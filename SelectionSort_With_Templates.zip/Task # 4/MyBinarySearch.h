#include "BinarySearch.h"
#include <iostream>
using namespace std;

template <class T>
int binarySearch(const T arr[], int size, T value) 
{
    int low = 0, high = size - 1;

    while (low <= high) 
    {
        int mid = (low + high) / 2;

        if (arr[mid] == value) 
        {
            return mid;
        }
        else if (arr[mid] < value) 
        {
            low = mid + 1;
        }
        else 
        {
            high = mid - 1;
        }
    }
    return -1;
}

template <class T>
void printSearchResult(int index, T value) 
{
    if (index != -1) 
    {
        cout << "Value " << value << " found at index " << index << "." << endl;
    }
    else 
    {
        cout << "Value " << value << " not found in the Array." << endl;
    }
}

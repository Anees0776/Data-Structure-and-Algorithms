#include "LinearSearch.h"
#include <iostream>
using namespace std;

template <class T>
int linearSearch(const T arr[], int size, T value) 
{
    for (int i = 0; i < size; i++) 
    {
        if (arr[i] == value) 
        {
            return i;
        }
    }
    return -1;
}

template <class T>
void printSearchResult(int index, T value) 
{
    if (index != -1) 
    {
        cout << "Value " << value << " found at index " << index << "." << endl;
    }
    else 
    {
        cout << "Value " << value << " not found in the Array." << endl;
    }
}


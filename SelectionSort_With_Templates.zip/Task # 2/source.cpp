#include<iostream>
#include<string>
#include "MySelectionSort.h"
using namespace std;

int main() 
{
    int intArray[5] = { 64, 25, 12, 22, 11 };
    cout << "Original Integer Array: ";
    printArray(intArray, 5);

    selectionSort(intArray, 5);
    cout << endl;

    cout << "Sorted Integer Array: ";
    printArray(intArray, 5);
    cout << endl;
    
    string stringArray[5] = { "Apple", "Orange", "Banana", "Grape", "Mango"};
    cout << "Original String Array: ";
    printArray(stringArray, 5);

    selectionSort(stringArray, 5);
    cout << endl;

    cout << "Sorted String Array: ";
    printArray(stringArray, 5);



    return 0;
}

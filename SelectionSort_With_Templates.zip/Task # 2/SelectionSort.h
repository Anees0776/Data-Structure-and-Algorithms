#pragma once
#include<iostream>
using namespace std;

template<class T>
void selectionSort(T arr[], int size);

template<class T>
void printArray(const T arr[], int size);

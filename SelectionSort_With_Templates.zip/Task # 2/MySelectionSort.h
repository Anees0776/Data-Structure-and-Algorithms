#pragma once
#include "SelectionSort.h"

template <class T>
void selectionSort(T arr[], int size) 
{
    for (int i = 0; i < size - 1; i++) 
    {
        int smallSub = i;
        for (int j = i + 1; j < size; j++) 
        {
            if (arr[j] < arr[smallSub]) 
            {
                smallSub = j;
            }
        }
        swap(arr[i], arr[smallSub]);
    }
}

template <class T>
void printArray(const T arr[], int size)
{
    for (int i = 0; i < size; i++) 
    {
        cout << arr[i] << " , ";
    }
    cout << endl;
}


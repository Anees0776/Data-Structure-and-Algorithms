#include<iostream>
using namespace std;

class Stack
{
protected:
	char* arr;
	int maxSize;
	int currentSize;
public:
	Stack(int size);
	virtual void push(char value) = 0;
	virtual char pop() = 0;
	virtual bool isEmpty() = 0;
	virtual bool isFull() = 0;
	virtual void display() = 0;
};

Stack::Stack(int size)
{
	maxSize = size;
	currentSize = 0;
	arr = new char[maxSize];
}



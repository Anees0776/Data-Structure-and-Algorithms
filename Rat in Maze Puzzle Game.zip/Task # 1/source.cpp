#include"mystack.h"
#include<iostream>
#include<fstream>
using namespace std;

const int rows = 4;
const int cols = 4;

void displayBoard(char board[rows][cols], int row, int col);
bool isValid(int newR, int newC, char board[rows][cols], int visited[rows][cols]);

int main()
{
	char board[rows][cols];
	int visited[rows][cols];

	ifstream fin;
	ofstream fout;
	fin.open("Input.txt");

	if (fin)
	{
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				fin >> board[i][j];  //Take input from file
			}
		}

		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				fin >> visited[i][j];   //Second board for store index where user alrady moves
			}
		}
	}
	else
	{
		cout << "Input File Can't Opened......! " << endl;
	}
	fin.close();

	int row = 0, col = 0;
	myStack moves(100);
	char input;    //take input for next move

	cout << "Initial Board: " << endl;
	displayBoard(board, row, col);

	bool reachedGoal = false;
	bool pathExist = false;

	while (!reachedGoal)
	{
		cout << endl;
		cout << "Enter Move(U,D,R,L) and Q to quit: ";
		cin >> input;

		if (input == 'q' || input == 'Q')  //Update the current position
		{
			break;
		}

		int newR = row;
		int newC = col;

		if (input == 'u' || input == 'U')
		{
			newR--;
		}
		else if (input == 'd' || input == 'D')
		{
			newR++;
		}
		else if (input == 'r' || input == 'R')
		{
			newC++;
		}
		else if (input == 'l' || input == 'L')
		{
			newC--;
		}
		else
		{
			cout << "Invalid Input " << endl;
			continue;
		}

		if (newR < 0 || newR >= rows || newC < 0 || newC >= cols) //check new move is within bound
		{
			cout << "Move out of Bound " << endl;
			continue;
		}

		if (isValid(newR, newC, board, visited)) //if next move is valid update visited position
		{
			visited[newR][newC] = -1;
			row = newR;
			col = newC;
			moves.push(input);

			cout << endl;
			cout << "Updated Board: " << endl;
			displayBoard(board, row, col);


			if (row == rows - 1 && col == cols - 1) //if user reached the goal
			{
				reachedGoal = true;
				pathExist = true;
				cout << endl;
				cout << "Congratulations! you have reached the goal " << endl;
				cout << "Your Movements Path: " << endl;
				moves.display();
				break;
			}
		}
		else
		{
			cout << "Please move to cell where 1 exists " << endl;
		}

		while(!reachedGoal && !isValid(row,col+1,board,visited) &&
        !isValid(row,col-1,board,visited) && !isValid(row+1,col,board,visited)
	    && !isValid(row - 1, col, board, visited))
		{
			if (moves.isEmpty())
			{
				cout << "No Valid moves left. Exiting...." << endl;
				break;
			}
			else  //backtrack the last movement if no valid path
			{
				char lastMove = moves.pop();
				cout << "Last Move was: " << lastMove << endl;

				visited[row][col] = -1;
				
				if (lastMove == 'u' || lastMove == 'U')
				{
					row++;
				}
				else if (lastMove == 'd' || lastMove == 'D')
				{
					row--;
				}
				else if (lastMove == 'l' || lastMove == 'L')
				{
					col++;
				}
				else if (lastMove == 'r' || lastMove == 'R')
				{
					col--;
				}

				cout << "Updated Board after backtracking:";
				displayBoard(board, row, col);
			}
		}
	}

	if (!pathExist)
	{
		cout << "Path doesn't Exists" << endl;
	}

	fout.open("Output.txt");

	int finalVisited[rows][cols];   //array to store final path 

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols;j++)
		{
			if (visited[i][j] == -1) //place 1 to index where user visit
			{
				finalVisited[i][j] = 1;
			}
			else  //else place 0
			{
				finalVisited[i][j] = 0;
			}
		}
	}

	if (!pathExist)
	{
		fout << "Path not Found " << endl;
	}
	else
	{
		fout << "Final Path: ";   //store final path in file 

		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols;j++)
			{

				fout << finalVisited[i][j] << " ";
			}
			fout << endl;
		}
	}
	cout << "Visited Path is stored in Output File " << endl;


	return 0;
}

void displayBoard(char board[rows][cols], int row, int col)
{
	for (int i = 0; i < rows; i++)
	{
		for(int j = 0; j < cols; j++)
		{ 
			if (i == row && j == col)
			{
				cout << "* ";   //Display Current Position on Board
			}
			else
			{
				cout << board[i][j] << " ";  //Display elements of board
			}
		}
		cout << endl;
	}
}


bool isValid(int newR, int newC, char board[rows][cols], int visited[rows][cols])
{
	//check index is not out of bound && moving path is valid
	return(newR >= 0 && newR < rows && newC >= 0 && newC < cols &&
		board[newR][newC] == '1' && visited[newR][newC] != -1);

}
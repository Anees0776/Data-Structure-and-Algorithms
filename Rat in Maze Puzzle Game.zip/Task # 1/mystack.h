#include "Stack.h"


class myStack :public Stack
{
public:
	void push(char value);
	char pop();
	myStack(int s);
	void display();
	bool isEmpty();
	bool isFull();
};

bool myStack::isFull()
{
	return currentSize == maxSize;
}

bool myStack::isEmpty()
{
	return currentSize == 0;
}

void myStack::display()
{

	for (int i = 0; i < Stack::currentSize; i++)
		cout << i + 1 << ". " << Stack::arr[i] << endl;
}

myStack::myStack(int s) :Stack(s)
{

}

void myStack::push(char value)
{
	if (isFull())
	{
		cout << "Stack is Full" << endl;
	}
	else
	{
		arr[currentSize] = value;
		currentSize++;
	}

}

char myStack::pop()
{
	if (isEmpty())
	{
		cout << "Stack in Empty" << endl;
		return NULL;
	}

	else
	{
		currentSize--;
		return arr[currentSize];
	}
}

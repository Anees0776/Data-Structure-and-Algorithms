#include<iostream>
#include<fstream>
#include"Node.h"
using namespace std;

class RedBlackTree
{
public:
	virtual void insert(int val) = 0;
	virtual void search(int val) = 0;
	virtual void findParent(int val) = 0;
	virtual void preOrderNLR() = 0;
	virtual void inOrderLNR() = 0;
	virtual void postOrderLRN() = 0;
	virtual void preOrder2NRL() = 0;
	virtual void inOrder2RNL() = 0;
	virtual void postOrder2RLN() = 0;
	virtual void insertFromFile() = 0;
	virtual void destroyTree() = 0;


};
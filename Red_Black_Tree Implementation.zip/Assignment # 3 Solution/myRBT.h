#include"RedBlackTree.h"

class MyRBT
{
private:
	Node* root;

	char getColor(Node* node);
	void setColor(Node* node, char c);
	Node* rotateLeft(Node* node);
	Node* rotateRight(Node* node);
	Node* balanceAfterInsertion(Node* node);
	Node* insertRecursive(Node* node, int val);
	void searchRecursive(Node* node, int val, bool& found);
	void findParentRecursive(Node* node, int val, Node* parent);
	void preOrder(Node* node);
	void inOrder(Node* node);
	void postOrder(Node* node);
	void preOrder2(Node* node);
	void inOrder2(Node* node);
	void postOrder2(Node* node);
	void destroy(Node* node);

public:
	void insert(int val);
	void search(int val);
	void findParent(int val);
	void preOrderNLR();
	void inOrderLNR();
	void postOrderLRN();
	void preOrder2NRL();
	void inOrder2RNL();
	void postOrder2RLN();
	void insertFromFile();
	void destroyTree();
	MyRBT();

};
MyRBT::MyRBT()
{
	root = nullptr;
}

char MyRBT::getColor(Node* node)
{
	if (node == nullptr)
	{
		return 'B';
    }
	else
	{
		return node->color;
	}
}

void MyRBT::setColor(Node* node, char c)
{
	if (node != nullptr)
	{
		node->color = c;
	}
}

Node* MyRBT::rotateLeft(Node* node)
{
	Node* R = node->right;
	node->right = R->left;
	R->left = node;
	return R;
}

Node* MyRBT::rotateRight(Node* node)
{
	Node* L = node->left;
	node->left = L->right;
	L->right = node;
	return L;
}

Node* MyRBT::balanceAfterInsertion(Node* node)
{
	if (node == nullptr)
	{
		return nullptr;
	}

	if (getColor(node->left) == 'R')
	{
		if (getColor(node->left->left) == 'R')
		{
			if (getColor(node->right) == 'R')
			{
				setColor(node->left, 'B');
				setColor(node->right, 'B');
				setColor(node, 'R');
			}
			else
			{
				node = rotateRight(node);
				setColor(node, 'B');
				setColor(node->right, 'R');
			}
		}

		else if (getColor(node->left->right) == 'R')
		{
			if (getColor(node->right) == 'R')
			{
				setColor(node->left, 'B');
				setColor(node->right, 'B');
				setColor(node, 'R');
			}
			else
			{
				node->left = rotateLeft(node->left);
				node = rotateRight(node);
				setColor(node, 'B');
				setColor(node->right, 'R');
			}
		}
	}

	else if (getColor(node->right) == 'R')
	{
		if (getColor(node->right->right) == 'R')
		{
			if (getColor(node->left) == 'R')
			{
				setColor(node->left, 'B');
				setColor(node->right, 'B');
				setColor(node, 'R');
			}
			else
			{
				node = rotateLeft(node);
				setColor(node, 'B');
				setColor(node->left, 'R');
			}
		}

		else if (getColor(node->right->left) == 'R')
		{
			if (getColor(node->left) == 'R')
			{
				setColor(node->left, 'B');
				setColor(node->right, 'B');
				setColor(node, 'R');
			}
			else
			{
				node->right = rotateRight(node->right);
				node = rotateLeft(node);
				setColor(node, 'B');
				setColor(node->left, 'R');
			}
		}
	}
	return node;
}

Node* MyRBT::insertRecursive(Node* node, int val)
{
	if (node == nullptr)
	{
		return new Node(val);
	}
	if (val < node->data)
	{
		node->left = insertRecursive(node->left, val);
	}
	else if (val > node->data)
	{
		node->right = insertRecursive(node->right, val);
	}

	return balanceAfterInsertion(node);
}

void MyRBT::insert(int val)
{
	root = insertRecursive(root, val);
	setColor(root, 'B');
}

void MyRBT::preOrder(Node* node)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	cout << node->data << "(" << node->color << ")" << endl;
	preOrder(node->left);
	preOrder(node->right);
}

void MyRBT::inOrder(Node* node)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	inOrder(node->left);
	cout << node->data << "(" << node->color << ")" << endl;
	inOrder(node->right);
}

void MyRBT::postOrder(Node* node)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	postOrder(node->left);
	postOrder(node->right);
	cout << node->data << "(" << node->color << ")" << endl;
}

void MyRBT::preOrder2(Node* node)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	cout << node->data << "(" << node->color << ")" << endl;
	preOrder2(node->right);
	preOrder2(node->left);
}

void MyRBT::inOrder2(Node* node)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	inOrder2(node->right);
	cout << node->data << "(" << node->color << ")" << endl;
	inOrder2(node->left);
}

void MyRBT::postOrder2(Node* node)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	postOrder2(node->right);
	postOrder2(node->left);
	cout << node->data << "(" << node->color << ")" << endl;
}

void MyRBT::preOrderNLR()
{
	preOrder(root);
	cout << endl;
}

void MyRBT::inOrderLNR()
{
	inOrder(root);
	cout << endl;
}

void MyRBT::postOrderLRN()
{
	postOrder(root);
	cout << endl;
}

void MyRBT::preOrder2NRL()
{
	preOrder2(root);
	cout << endl;
}

void MyRBT::inOrder2RNL()
{
	inOrder2(root);
	cout << endl;
}

void MyRBT::postOrder2RLN()
{
	postOrder2(root);
	cout << endl;
}

void MyRBT::searchRecursive(Node* node, int val, bool& found)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	if (node->data == val)
	{
		cout << "Found: " << node->data << "(" << node->color << ")" << endl;
		found = true;
		return;
	}
	if (val < node->data)
	{
		searchRecursive(node->left, val, found);
	}
	else
	{
		searchRecursive(node->right, val, found);
	}
}

void MyRBT::search(int val)
{
	bool found = false;
	searchRecursive(root, val, found);
	if (!found)
	{
		cout << "Value not found " << endl;
	}
}

void MyRBT::findParentRecursive(Node* node, int val, Node* parent)
{
	if (node == nullptr)
	{
		cout << "Tree is Empty " << endl;
		return;
	}
	if (node->data == val)
	{
		if (parent == nullptr)
		{
			cout << "Root Node has no Parent " << endl;
			return;
		}
		else
		{
			cout << "Parent of " << val << " is " << parent->data << "(" << parent->color << ")" << endl;
			return;
		}
	}
	if (val < node->data)
	{
		findParentRecursive(node->left, val, node);
	}
	else
	{
		findParentRecursive(node->right, val, node);
	}
}

void MyRBT::findParent(int val)
{
	findParentRecursive(root, val, nullptr);
}

void MyRBT::insertFromFile()
{
	ifstream fin("input.txt");
	if (!fin.is_open())
	{
		cout << "File not found " << endl;
		return;
	}
	int value;
	while (fin >> value)
	{
		insert(value);
	}
	fin.close();
}

void MyRBT::destroy(Node* node)
{
	if (node == nullptr)
	{
		return;
	}
	destroy(node->left);
	destroy(node->right);
	delete node;
	node = nullptr;
}

void MyRBT::destroyTree()
{
	destroy(root);
}



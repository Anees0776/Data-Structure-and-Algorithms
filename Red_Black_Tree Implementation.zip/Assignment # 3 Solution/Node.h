struct Node
{
	int data;
	char color;
	Node* left;
	Node* right;

	Node(int val)
	{
		data = val;
		color = 'R'; 
		left = nullptr;
		right = nullptr;
	}
};

#include"myRBT.h"

int main()
{
	int choice, value;
	MyRBT tree;
	do
	{
		cout << endl;
		cout << "......Red Black Tree......" << endl;
		cout << "Press 1 to insert value in tree " << endl;
		cout << "Press 2 for search a value in tree " << endl;
		cout << "Press 3 for Pre-Order Traversal (NLR) " << endl;
		cout << "Press 4 for In-Order Traversal (LNR) " << endl;
		cout << "Press 5 for Post-Order Traversal (LRN) " << endl;
		cout << "Press 6 for Pre-Order Traversal (NRL) " << endl;
		cout << "Press 7 to for In-Order Traversal (RNL) " << endl;
		cout << "Press 8 to for Post-Order Traversal (RLN) " << endl;
		cout << "Press 9 for dislay parent of a node " << endl;
		cout << "Press 10 to read integer values from file " << endl;
		cout << "Press 11 to destroy the tree " << endl;
		cout << "Press 12 to Exit " << endl;
		cout << "Enter your choice: ";
		cin >> choice;

		switch (choice)
		{
		case 1:
			cout << "Enter Value to insert: ";
			cin >> value;
			tree.insert(value);
			break;

		case 2:
			cout << "Enter value to search: ";
			cin >> value;
			tree.search(value);
			break;

		case 3:
			cout << "Pre-Order Traversal NLR: " << endl;
			tree.preOrderNLR();
			break;

		case 4:
			cout << "In-Order Traversal LNR: " << endl;
			tree.inOrderLNR();
			break;

		case 5:
			cout << "Post-Order Traversal LRN: " << endl;
			tree.postOrderLRN();
			break;

		case 6:
			cout << "Pre-Order Traversal NRL: " << endl;
			tree.preOrder2NRL();
			break;

		case 7:
			cout << "In-Order Traversal RNL: " << endl;
			tree.inOrder2RNL();
			break;

		case 8:
			cout << "Post-Order Traversal RLN: " << endl;
			tree.postOrder2RLN();
			break;

		case 9:
			cout << "Enter value to find its Parent: ";
			cin >> value;
			tree.findParent(value);
			break;

		case 10:
			cout << "Values inserted from File " << endl;
			tree.insertFromFile();
			break;

		case 11:
			cout << "Tree is Destroyed " << endl;
			tree.destroyTree();
			break;

		case 12:
			cout << "Exiting...." << endl;
			tree.destroyTree();
			break;

		default:
			cout << "Invalid Choice! Try Again " << endl;
		}
	} 
	while (choice != 12);



	return 0;
}
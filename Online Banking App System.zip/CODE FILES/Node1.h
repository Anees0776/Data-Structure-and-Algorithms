struct BSTNode
{
    Account data;
    BSTNode* leftChild;
    BSTNode* rightChild;
};
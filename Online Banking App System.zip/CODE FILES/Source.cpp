﻿#include <iostream>
#include <fstream>
#include <conio.h> 
#include <ctime>
#include <string>
#include <ctime>
#include <iomanip>
#include <windows.h>
#include "myDLL.h"
#include"BST.h"
#include"MyLoanManager .h"
#include"Passbook.h"
using namespace std;
void printColorText(string text, int fgColor, int bgColor) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	int colorCode = (bgColor << 4) | fgColor;
	SetConsoleTextAttribute(hConsole, colorCode);

	cout << text;

	SetConsoleTextAttribute(hConsole, 7);
}
void AdminInstructionsPrinter(){
	printColorText("Press 1 to Add a New Admin", 7, 9); //text color, bg color
	cout << endl;
	printColorText("Press 2 to View All Customers", 7, 9); //text color, bg color
	cout << endl;
	printColorText("Press 3 to Create New Customer Account", 7, 9); //text color, bg color
	cout << endl;
	printColorText("Press 4 to View All Transactions Of A User", 7, 9); //text color, bg color
	cout << endl;
	printColorText("Press 5  to File a Loan Appliction", 7, 9);
	cout << endl;
	printColorText("Press 6  to Check Loan Status", 7, 9);
	cout << endl;


	printColorText("Press 7  to Approve Next Loan", 7, 9);
	cout << endl;

	printColorText("Press 8  to View Pending Loan", 7, 9);
	cout << endl;

	printColorText("Press 9 to Reject Next Loan (Admin Only)", 7, 9);
	cout << endl;
	printColorText("Press 10 to exit", 7, 9);
	cout << endl;

}
void userInstructionsPrinter(){
	printColorText("Press 1  to View Account Balance", 7, 9);
	cout << endl;
	printColorText("Press 2  to Transfer Funds", 7, 9);
	cout << endl;
	printColorText("Press 3  to View Deposit History (Ascending Order)", 7, 9);
	cout << endl;
	printColorText("Press 4  to View Month with Highest Spending", 7, 9);
	cout << endl;
	printColorText("Press 5  to View Recent Withdrawals (Highest to Lowest)", 7, 9);
	cout << endl;
	printColorText("Press 6  to View Recent Withdrawals (Lowest to Highest)", 7, 9);
	cout << endl;
	printColorText("Press 7  to Apply for a Loan", 7, 9);
	//cout << endl;
	//printColorText("Press 8  to Check Loan Status", 7, 9);
	cout << endl;
	printColorText("Press 8 to View Passbook", 7, 9);
	cout << endl;
	printColorText("Press 9 to View All Transactions (Descending Order)", 7, 9);
	cout << endl;
	printColorText("Press 10 to View Deposit History (Descending Order)", 7, 9);
	cout << endl;
	printColorText("Press 11 to View Transaction History", 7, 9);
	cout << endl;

	printColorText("Press 12 to View Month with Lowest Spending", 7, 9);
	cout << endl;
	printColorText("Press 13 to Exit", 7, 9);
	cout << endl;

}
bool passwordChecker(string str){
	int Tlength = 0, UpperCaselength = 0, LowerCaselength = 0, Symbolslength = 0, pattCount = 0, digitsCount = 0;
	for (int i = 0; i < str.length(); i++)
	{
		if (str[i] >= 65 && str[i] <= 90){
			UpperCaselength++;
			Tlength++;
		}
		else if (str[i] >= 97 && str[i] <= 122){
			LowerCaselength++;
			Tlength++;
		}
		else if (str[i] >= 48 && str[i] <= 57){
			digitsCount++; Tlength++;
		}
		else{
			if (str[i] != 32){
				Symbolslength++;
				Tlength++;
			}
		}
	}

	//Now checking patterns in passwords for instance saad12345
	//patt check
	for (int i = 0; i < str.length(); i++)
	{
		if (str[i] >= 48 && str[i] <= 57){
			int ascii = str[i];
			if (str[i + 1] == ascii + 1){
				ascii = str[i + 1];
				if (str[i + 1 + 1] == ascii + 1){
					pattCount++;
					break;
				}
			}
		}

	}

	if (UpperCaselength >= 1 && LowerCaselength >= 1 && digitsCount >= 1 && Symbolslength >= 1 && pattCount <= 0){
		return true;
	}
	else{
		return false;
	}
}
string getPswdHiddenInput() {
	string password;
	char character;

	while (true) {
		character = _getch();
		if (character == 13) {
			cout << endl;
			break;
		}
		else if (character == 8) {
			if (!password.empty()) {
				password.pop_back();
				cout << "\b \b";
			}
		}
		else {
			password += character;
			cout << '*';
		}
	}

	return password;
}
void VerifiedPrinter(){
	time_t start = time(0);
//	cout << "."; cout << "."; cout << "."; cout << "\b \b"; cout << "."; cout << "."; cout << ".";
	while (true) {
		time_t now = time(0);
		double elapsed = difftime(now, start);
		//		if (elapsed == 1 || elapsed == 2||elapsed == 3){ cout << "."; }
		if (elapsed >= 3) {
			printColorText("Verified!", 10, 16); //text color, bg color
			cout << endl;
			break;
		}
	}
}
void DateTimePrinter(){
	cout << __DATE__ << "   ";
	cout << __TIME__ << endl;
}
bool EmailVerifier(string email){
	int count = 0;
	for (int i = 0; i < email.length(); i++)
	{
		if (email[i] == '@'){
			count++;
		}
		while (count >= 1 && i < email.length()){
		if (email[i] == '.'){
			count++;
		}
		else if (email[i] == 'c' && email[i + 1] == 'o' && email[i + 1+1] == 'm'){
			count++;
		}
		i++;
		if (i>email.length()){
			break;
		}
		}
	}
	if (count>=3){
		return true;
	}
	else{
		return false;
	}
}
string  adminVerifier(string email, string pswd, ifstream&fin){
	string temp,temp1,temp2; bool found = false;
	while (getline(fin,temp)){
		getline(fin, temp1);
		getline(fin, temp2);//ignore admin name 
	//	fin.ignore();
		if (temp==email){
			if (temp1==pswd){
				found = true; 
				break;
			}
			else{ found = false; }
		}
	}if (found){
		return temp2;
	}
	else{
		return "";
	}
}
string  UserVerifier(string email, string pswd, ifstream&fin){
	string temp; bool found = false;
	while (getline(fin, temp)){
		found = true;
		if (temp == email){
			getline(fin, temp);
			if (temp == pswd){
				found = true; getline(fin, temp); break;
			}
			else{ found = false; }
			getline(fin, temp);//ignore user name 
		}
	}if (found){
		return temp;
	}
	else{
		return "";
	}
}
bool SecurityKeyVerifier(string key,ifstream&fin){
	string temp;
	getline(fin, temp);
	return temp == key;
}
string GreetingsPrinter() {
	time_t now = time(0);
	tm ltm;
	localtime_s(&ltm, &now);

	int hour = ltm.tm_hour;

	if (hour < 12) return "Good morning, ";
	else if (hour <17) return "Good afternoon, ";
	else return "Good evening, ";
}
int generateAccountNo() {
	ifstream fin("AccountNumber.txt");
	ofstream fout("AccountNumber.txt"); 
	int temp; fin >> temp;
	static int lastAccountNo = temp;
	temp = temp + 1;
	fout << temp;
	fin.close(); fout.close();
	return ++lastAccountNo;
}
int AccExists(int acc){
	string name; int tempAcc; int bal; bool found = false;
	ifstream fin("UserDetails.txt");
	while (!fin.eof()){
		getline(fin,name,',');
		fin >> bal;
		fin.ignore();
		fin >> tempAcc;
		if (tempAcc == acc){
			found = true;
			break;
		}
		fin.ignore();
	}
	if (found){
		return bal;
	}
	else{
		return -1;
	}
	
}
int AccFinder(string acc){
	string name; int tempAcc; int bal; bool found = false;
	ifstream fin("UserDetails.txt");
	while (!fin.eof()){
		getline(fin, name, ',');
		fin >> bal;
		fin.ignore();
		fin >> tempAcc;
		if (name== acc){
			found = true;
			break;
		}
		fin.ignore();
	}
	if (found){
		return tempAcc;
	}
	else{
		return -1;
	}

}
bool UpdateBal(int balUpdate,int acc){
	string name; int tempAcc; int bal; bool found = false;
	ifstream fin("UserDetails.txt");
	ofstream fout("temp.txt");
	myDLL obj;
	while(!fin.eof()){
		getline(fin, name, ',');
		fin >> bal;
		fin.ignore();
		fin >> tempAcc;
		Account aobj(name, bal, tempAcc);
		obj.insertAtTail(aobj);
		//		fout << name << endl;
		fin.ignore();
	}
	fout.close(); fin.close();
	 fout.open("UserDetails.txt");
//	 fin.open("temp.txt");
	 while (!obj.isEmpty()){
	//	 getline(fin, name, ',');
		// fin >> bal;
		 //fin.ignore();
		 //fin >> tempAcc;
		 Account Tobj = obj.deleteFromHead();
		/*if (name == ""){
			 break;
		 }*/
		 if (Tobj.accno== acc){
			 Tobj.ball= balUpdate;
			 found = true;
		 }
//		 fin.ignore();
		 if (Tobj.name != ""){
			 fout << Tobj.name << "," << Tobj.ball<< "," << Tobj.accno << endl;
		 }
	 }
	 fout.close();
	return found;
}
string AccNameFinder(int acc){
	string name; int tempAcc; int bal; bool found = false;
	ifstream fin("UserDetails.txt");
	while (!fin.eof()){
		getline(fin, name, ',');
		fin >> bal;
		fin.ignore();
		fin >> tempAcc;
		if (tempAcc == acc){
			found = true;
			break;
		}
		fin.ignore();
	}
	if (found){
		return name;
	}
	else{
		return "";
	}
}
void WithdrawUpdater(string name,int amount){
	string transactionHistory = name + "TransactionHistory.txt";
	name = name + "Withdraw.txt";
	ofstream fout(name, ios::app);
	ofstream foutT(transactionHistory, ios::app);
	time_t now = time(0);
	tm ltm;                      //   
	localtime_s(&ltm, &now);     //  
	foutT << +1 << ",";
	foutT << put_time(&ltm, "%Y-%m-%d");
	foutT << "," << amount << endl;

	fout << put_time(&ltm, "%Y-%m-%d");
	fout << "," << amount << endl;
	// Format: YYYY-MM-DD

	fout.close();
}
void DepositUpdater(string name, int amount){
	string transactionHistory = name + "TransactionHistory.txt";
	name = name + "Deposits.txt";
	ofstream fout(name, ios::app);
	ofstream foutT(transactionHistory, ios::app);
	time_t now = time(0);
	tm ltm;                      
	localtime_s(&ltm, &now);     

	fout << put_time(&ltm, "%Y-%m-%d");
	foutT << -1<<",";
	foutT << put_time(&ltm, "%Y-%m-%d");
	foutT << "," << amount << endl;
	fout << "," << amount << endl;
	// Format: YYYY-MM-DD

	fout.close();
}
void FillTreeTransaction(ifstream &usernameTrans, BST &obj){
	int temp=0;
//	string date;
	Account TempObj;
	if (!usernameTrans.eof()){
		usernameTrans >> TempObj.code;
		usernameTrans.ignore();
		getline(usernameTrans, TempObj.name, ',');
		usernameTrans >> TempObj.ball;
		//		cout << date[5] << Tdate[0] << date[6] << Tdate[1];
		if (TempObj.name!=""){
			obj.insert(TempObj);
		}usernameTrans.ignore();
		FillTreeTransaction(usernameTrans, obj);
	}
	else{ return; }
}
void FillTree(ifstream &usernameDeposits, BST &obj){
	int temp;
	string date;
	Account TempObj;
	if (!usernameDeposits.eof()){
		getline(usernameDeposits, TempObj.name, ',');
		usernameDeposits >> TempObj.ball;
		//		cout << date[5] << Tdate[0] << date[6] << Tdate[1];
		obj.insert(TempObj);
		usernameDeposits.ignore();
		FillTree(usernameDeposits, obj);
	}
	else{ return; }
}
void FillLLD(ifstream &usernameDeposits, myDLL &obj, string Tdate){
	int temp=0;
	string date;
	Account tobj;
	if (!usernameDeposits.eof()){
		getline(usernameDeposits, tobj.name, ',');//using name variable for date
		usernameDeposits >> tobj.ball;
		//		cout << date[5] << Tdate[0] << date[6] << Tdate[1];
		//if (tobj.name[5] == Tdate[0] && tobj.name[6] == Tdate[1]){
		// temp = tobj.ball;
		obj.insertSorted(tobj);
		//}
		usernameDeposits.ignore();
		if (tobj.name!=""){
			FillLLD(usernameDeposits, obj, Tdate);
		}
	}
	else{ return; }

}
void FillLLDM(ifstream &usernameDeposits, myDLL &obj, string Tdate){
	int temp=0;
	string date;
	Account tobj;
	if (!usernameDeposits.eof()){
		usernameDeposits >> tobj.code; usernameDeposits.ignore();
		getline(usernameDeposits, tobj.name, ',');//using name variable for date
		usernameDeposits >> tobj.ball;
		//		cout << date[5] << Tdate[0] << date[6] << Tdate[1];
		if (tobj.name == ""){
			return;
		}
		if (tobj.name[5] == Tdate[0] && tobj.name[6] == Tdate[1]){
		// temp = tobj.ball;
			if (tobj.name != ""){
				obj.insertAtTail(tobj);
			}
		}
		usernameDeposits.ignore();
			FillLLDM(usernameDeposits, obj, Tdate);
		}
	else{ return; }
}
int monthCheck(string date){
	if (date[5] == '0'&& date[6] == '1'){
		return 1;
	}
	else if (date[5] == '0'&& date[6] == '2'){
		return 2;
	}
	else if (date[5] == '0'&& date[6] == '3'){
		return 3;
	}
	else if (date[5] == '0'&& date[6] == '4'){
		return 4;
	}
	else if (date[5] == '0'&& date[6] == '5'){
		return 5;
	}
	else if (date[5] == '0'&& date[6] == '6'){
		return 6;
	}
	else if (date[5] == '0'&& date[6] == '7'){
		return 7;
	}
	else if (date[5] == '0'&& date[6] == '8'){
		return 8;
	}
	else if (date[5] == '0'&& date[6] == '9'){
		return 9;
	}
	else if (date[5] == '0'&& date[6] == '10'){
		return 10;
	}
	else if (date[5] == '0'&& date[6] == '11'){
		return 11;
	}
	else if (date[5] == '0'&& date[6] == '12'){
		return 12;
	}
	else{
		return 0;
	}
}
void FillTree2(ifstream &usernameDeposits, BST &obj,int arr[]){
	int temp=0;
	string date;
	Account TempObj;
	if (!usernameDeposits.eof()){
		getline(usernameDeposits, TempObj.name, ',');
		usernameDeposits >> TempObj.ball;
		arr[monthCheck(TempObj.name)] = arr[monthCheck(TempObj.name)] + TempObj.ball;
			obj.insert(TempObj);
			usernameDeposits.ignore();
			FillTree2(usernameDeposits, obj,arr);
	}

	if (usernameDeposits.eof()){ return; }

}
//void FillTreeM(ifstream &usernameDeposits, BST &obj, string Tdate){
////fill tree acc to month
//	int temp;
//	string date;
//	if (!usernameDeposits.eof()){
//		getline(usernameDeposits, date, ',');
//		usernameDeposits >> temp;
//		//		cout << date[5] << Tdate[0] << date[6] << Tdate[1];
//		if (date[5] == Tdate[0] && date[6] == Tdate[1]){
//			obj.insert(temp);
//		}
//		usernameDeposits.ignore();
//		FillTreeM(usernameDeposits, obj, Tdate);
//	}
//	else{ return; }
//}

int main() {
	int attempts = 0;
	int option = 0; MyLoanManager loanSys;
	printColorText("Press 1 to Enter Admin Mode", 16, 7); //text color, bg color
	cout << endl;
	printColorText("Press 2 to Enter User Mode", 16, 7); //text color, bg color
	cout << endl;
	cout<<"Enter Option:"; //text color, bg color
	cin >> option;
	cin.ignore();

	if (option==1)
	{
		printColorText("                        Admin Mode                        ", 7, 5); //text color, bg color
		cout << endl;
		ifstream fin("admin.txt");
		ifstream key("key.txt");
		ofstream fout("admin.txt", ios::app);
		string email, pass; string name;
		do{
			fin.open("admin.txt");
			attempts++;
			printColorText("Enter E-mail: ", 7, 9); //text color, bg color
			getline(cin, email);
			printColorText("Enter Password: ", 7, 9); //text color, bg color
			pass = getPswdHiddenInput();
			 name = adminVerifier(email, pass, fin);
			 fin.close();
			//if admin exists...
			 if (name == ""){
				 printColorText("Invalid credentials! Please try again.", 4, 16); //text color, bg color
				 cout << endl;
			 }
			 if (attempts == 3 && name == ""){
				 printColorText("Too many failed login attempts. Try again later.", 4, 16); //text color, bg color
				 cout << endl; 
				 break;
			 }

		} while (name == "");
		if (name != "")
		{
			VerifiedPrinter();
			cout << GreetingsPrinter();
			printColorText(name, 9, 16); //text color, bg color
			cout << endl;
			DateTimePrinter();
			int numb = 0;
			AdminInstructionsPrinter();
			do{
			cout << "Enter Choice:";
			cin >> numb;
			//		cin.ignore();
			switch (numb)
			{
			case 1: {
						SecurityKeyVerifier("$hotb&ck$!", key);

						// Email Input		
						cin.ignore();

						printColorText("Enter E-mail: ", 7, 9);
						getline(cin, email);

						while (!EmailVerifier(email)) {
							cout << "Invalid email format. Try again.\n";
							printColorText("Enter E-mail: ", 7, 9);
							getline(cin, email);
						}
						cout << "Email format is valid!\n";
						fout << email << endl;

						// Password Input
						printColorText("Enter Password: ", 7, 9);
						pass = getPswdHiddenInput();
						//					cin.ignore(); 

						while (!passwordChecker(pass)) {
							cout << "Your Password is Not Strong! Try again.\n";
							printColorText("Enter Password: ", 7, 9);
							pass = getPswdHiddenInput();
						}

						cout << "Your Password is Strong and ready to go!" << endl;
						fout << pass << endl;

						// Name Input
						printColorText("Enter Your Name: ", 7, 9);
						getline(cin, name);
						fout << name << endl;
						cout << name << " Added!" << endl;

						break;
			}
			case 2:{
					   ifstream fin("users.txt");
					   string temp;
					   printColorText("Users: ", 7, 9); cout << endl;
					   while (!fin.eof()){
						   getline(fin, temp);
						   getline(fin, temp);
						   getline(fin, temp);
						   printColorText(temp, 7, 9); cout << endl;
					   }
					   break;
			}
			case 3:{
					   ofstream foutUsers("users.txt", ios::app);
					   // Email Input
					   cin.ignore();
					   printColorText("Enter E-mail: ", 7, 9);
					   getline(cin, email);

					   while (!EmailVerifier(email)) {
						   cout << "Invalid email format. Try again.\n";
						   printColorText("Enter E-mail: ", 7, 9);
						   getline(cin, email);
					   }
					   cout << "Email format is valid!\n";
					   foutUsers << email << endl;

					   // Password Input
					   printColorText("Enter Password: ", 7, 9);
					   pass = getPswdHiddenInput();
					   //					cin.ignore(); 

					   while (!passwordChecker(pass)) {
						   cout << "Your Password is Not Strong! Try again.\n";
						   printColorText("Enter Password: ", 7, 9);
						   pass = getPswdHiddenInput();
					   }

					   cout << "Your Password is Strong and ready to go!" << endl;
					   foutUsers << pass << endl;

					   // Name Input
					   printColorText("Enter Your Name: ", 7, 9);
					   getline(cin, name);
					   foutUsers << name << endl;
					   cout << name << " Added!" << endl;
					   ofstream SaveNewUserDetails("UserDetails.txt");
					   SaveNewUserDetails << name << "," << 0 << generateAccountNo() << endl;

					   break;
			}
			case 4:{
					   int acc;
					   BST obj;
					   cout << "Enter Account Number:"; cin >> acc;
					   string filename = AccNameFinder(acc) + "TransactionHistory.txt";
					   ifstream fin(filename);
					   FillTreeTransaction(fin, obj);
					   cout << "Date        | Type       | Amount   |\n";
					   cout << "------------|------------|----------|\n";

					   obj.preorder();
					   cout << "------------|------------|----------|\n";
					   break;
			}
			case 5:{
					   string id, user, date;
					   float amt, rate;
					   cout << "Enter Loan ID: ";
					   cin >> id;
					   cin.ignore();
					   cout << "Enter Username: "; getline(cin, user);
					   //	   cin.ignore();
					   cout << "Enter Loan Amount: "; cin >> amt;
					   cin.ignore();
					   cout << "Enter Interest Rate (%): "; cin >> rate;
					   cin.ignore();
					   cout << "Enter Application Date (YYYY-MM-DD): "; getline(cin, date);
					   loanSys.applyForLoan(id, user, amt, rate, date);
					   break; }
			case 6:
			{
					  loanSys.showNextLoan();
					  break;
			}   
			case 7: {
				loanSys.processNextLoanApproval();
				break;
			}

			case 8: {
						loanSys.showNextLoan();
						break;
			}

			case 9: {
						 loanSys.rejectNextLoan();
						 break;
			}
			case 10:{break; }
			default:{
						printColorText("Wrong Input!\n", 4, 16); //text color, bg color
						break;
						cout << "Enter Choice:";
						cin >> numb;
						break;
			}
			}
		}while (numb!=10);
		}
		// if admin doesnt exists..
		else{
			printColorText("Incorrect Details!", 4, 16); //text color, bg color
			cout << endl;
		}

	}
	else if (option == 2){
		printColorText("                        User Mode                        ", 7, 5); cout << endl;//text color, bg color
		int attempts = 0;
		//	cin.ignore();
		ifstream users("users.txt");
		string name; 	string email, pass;
do{		
	attempts++;
	    printColorText("Enter E-mail: ", 7, 9); //text color, bg color
		getline(cin, email);
		printColorText("Enter Password: ", 7, 9); //text color, bg color
		pass = getPswdHiddenInput();
		users.open("users.txt");
	name = UserVerifier(email, pass, users);
	users.close();
		if (name == ""){
			printColorText("Invalid credentials! Please try again.", 4, 16); //text color, bg color
			cout << endl;
		}
		if (attempts==3&&name==""){
			cout << "Too many failed login attempts. Try again later." << endl; break;
		}
	} while (name == "");

	if (name != "")
		{
			VerifiedPrinter();
			cout << GreetingsPrinter();
			printColorText(name, 9, 16); //text color, bg color
			cout << endl;
			DateTimePrinter();
			int numb = 0;
			do{
				userInstructionsPrinter();
				cout<<"Enter Choice :";
				cin >> numb;
				//		cin.ignore();
				switch (numb)
				{
				case 1:{
						   cout<<"Current Balance:\t";
						   if (AccExists(AccFinder(name))<1000){
							   printColorText2(AccExists(AccFinder(name)), 4, 16); //text color, bg color
							   cout << "PKR";
							   cout << endl;
						   }
						   else{
							   printColorText2(AccExists(AccFinder(name)), 10, 16); //text color, bg color
							   cout << "PKR";
							   cout << endl;
						   }
						   break;
				}
				case 2:{
						   int accNo, temp, bal2 = 0;
						   printColorText("Enter the account number of the recipient:", 16, 7);
						   cin >> accNo;
						   int bal = AccExists(accNo);
						   if (bal != -1){
							   printColorText("Enter Amount:", 16, 7);
							    cin >> temp; bal = bal + temp;
							   bal2 = AccExists(AccFinder(name));
							   if (bal2 >= temp){
								   if (UpdateBal(bal, accNo)){
									   printColorText2(temp, 4, 16); //text color, bg color
									   cout << " PKR transferred to Account No. " << accNo
										   << " on " << __DATE__ << " at " << __TIME__ << "." << endl;
									   DepositUpdater(AccNameFinder(accNo), temp);
									   UpdateBal(bal2 - temp, AccFinder(name));
									   WithdrawUpdater(AccNameFinder(AccFinder(name)), temp);//

									   DepositUpdater(AccNameFinder(accNo), temp);
									   WithdrawUpdater(AccNameFinder(AccFinder(name)), temp);//

								   }
							   }
							   else{

							   }
						   }
						   else{
							   printColorText("Invalid Account Number!\n", 4, 16); //text color, bg color
						   }
						   break; }
				case 3:
				{
						  int acc;
						  myDLL OBJ;
						  acc = AccFinder(name);
						  //printColorText("Enter Your Account Number:", 16, 7);
						  //cin >> acc;
						  string filename = AccNameFinder(acc) + "Deposits.txt";
						  ifstream fin(filename);
						  if (fin){
							  FillLLD(fin, OBJ, "06");
							  OBJ.displayFromHead();
						  }
						  else{
							  printColorText("Wrong Input!", 4, 16); //text color, bg color

						  }
						  break;
				}
				case 4:{
						   int acc;
						   acc = AccFinder(name);
						   //printColorText("Enter Your Account Number:", 16, 7);
						   //cin >> acc;
						   string filename = AccNameFinder(acc) + "Withdraws.txt";
						   ifstream fin(filename);
						   BST obj;
						   int arr[13];
						   for (int i = 0; i < 13; i++)
						   {
							   arr[i] = 0;
						   }
						   FillTree2(fin, obj, arr);
						   fin.close();
						   int max = arr[1];
						   int maxindex = 0;
						   for (int i = 1; i <= 12; i++)
						   {
							   if (max < arr[i]){
								   max = arr[i];
								   maxindex = i;
							   }
						   }
						   cout << "Most Spending Month:\t" << maxindex << " Total Spending: " << max << " PKR" << endl;
						   break;



				}

				case 5:{
						   int acc;
						   myDLL OBJ;
						   acc = AccFinder(name);
						   //printColorText("Enter Your Account Number:", 16, 7);
         //                  cin >> acc;
						   string filename = AccNameFinder(acc) + "Withdraws.txt";
						   ifstream fin(filename);
						   FillLLD(fin, OBJ, "06");
						   OBJ.displayFromTail();
						   break;			}
				case 6:{
						   int acc;
						   myDLL OBJ;
						   //				   BST obj;
						   acc = AccFinder(name);
						   string filename = AccNameFinder(acc) + "Withdraws.txt";
						   ifstream fin(filename);
						   FillLLD(fin, OBJ, "06");
						   //					   obj.preorder();
						   OBJ.displayFromHead();
						   break;

				}
				case 8:{
							Passbook pobj;
							pobj.loadFile(AccNameFinder(AccFinder(name)));
							pobj.displayPassbook();
							break;
				}
				case 9:{
							int acc;
							BST obj;
							//printColorText("Enter Your Account Number:", 16, 7);
							//cin >> acc;
							acc = AccFinder(name);
							string filename = AccNameFinder(acc) + "TransactionHistory.txt";
							ifstream fin(filename);
							FillTreeTransaction(fin, obj);
							cout << "Date        | Type       | Amount   |\n";
							cout << "------------|------------|----------|\n";
							obj.preorder();
							cout << "------------|------------|----------|\n";
							break; }
				case 7:{
						   string id, user, date;
						   float amt, rate;
						   cout << "Enter Loan ID: "; cin >> id;
						   cout << "Enter Username: "; cin >> user;
						   cout << "Enter Loan Amount: "; cin >> amt;
						   cout << "Enter Interest Rate (%): "; cin >> rate;
						   cout << "Enter Application Date (YYYY-MM-DD): "; cin >> date;
						   loanSys.applyForLoan(id, user, amt, rate, date);
						   break; }
				case 10:{
							int acc;
							myDLL OBJ;
							acc = AccFinder(name);

							//printColorText("Enter Your Account Number:", 16, 7);
							//cin >> acc;
							string filename = AccNameFinder(acc) + "Deposits.txt";
							ifstream fin(filename);
							FillLLD(fin, OBJ, "06");
							OBJ.displayFromTail();
							break; }
				case 11:{
							int acc; string month;
							myDLL obj;
							acc = AccFinder(name);
							//printColorText("Enter Your Account Number:", 16, 7);
							//cin >> acc;
							printColorText("Enter Month (in MM format, e.g., 01 for January): ", 16, 7);
							cin >> month;
							string filename = AccNameFinder(acc) + "TransactionHistory.txt";
							ifstream fin(filename);
							FillLLDM(fin, obj, month);
							cout << "Date        | Type       | Amount   |\n";
							cout << "------------|------------|----------|\n";
							obj.displayFromHead();
							cout << "------------|------------|----------|\n";

							break;
				};
				case 12:{

							int acc;
							acc = AccFinder(name);
							//printColorText("Enter Your Account Number:", 16, 7);
							//cin >> acc;
							string filename = AccNameFinder(acc) + "Withdraws.txt";
							ifstream fin(filename);
							BST obj;
							int arr[13];					
							for (int i = 0; i < 13; i++)
							{
								arr[i] = 0;
							}

							FillTree2(fin, obj, arr);
							fin.close();
							int max = INT_MAX;
							int maxindex = 0;
							for (int i = 1; i <= 12; i++)
							{
								if (max > arr[i]){
									max = arr[i];
									maxindex = i;
								}
							}
							cout << "Lowest Spending Month:\t"; printColorText2(maxindex, 4, 16); cout << " Total: " << max << " PKR" << endl;
							break;

							break;
				}
				case 13:{
							printColorText("Your Account Number:", 7, 9); // text color, bg color
							cout << AccFinder(name) << endl;

							break; }
				default:{

							printColorText("Wrong Input!\n", 4, 16); //text color, bg color
							break;
				}
				}
			}


			while (numb != 15);
		}
		else{
			printColorText("Invalid credentials! Access denied.", 4, 16); //text color, bg color
			cout << endl;
		}
	}
	else{
		printColorText("Wrong Input!", 4, 16); //text color, bg color
		cout << endl;
	}
	return 0;
}
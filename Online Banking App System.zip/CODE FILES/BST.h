#include "Tree.h"

class BST:public Tree
{
	void POSTORDER(BSTNode*p);
	void PREORDER(BSTNode*p);
	void INORDER(BSTNode*p);
	void INORDER2(BSTNode*p);
public:
	void insert(Account);
    void inorder();
    void inorder2();
    void preorder();
    void postorder();
	bool deleteNode(Account value);
    bool isEmpty();
	void wrapperMax(){
		maxfind(root);
	}
	void maxfind(BSTNode *t){
		if (t->rightChild == nullptr){
			cout << "Most Spending Month:\t" << t->data << endl;
			return;
		}
		maxfind(t->rightChild);

	}
};
bool BST::deleteNode(Account value)
{
    if (isEmpty())
        return false;

    else if (root->leftChild == nullptr && root->rightChild == nullptr) //single node case
    {
        if (root->data == value)
        {
            delete root;
            root = nullptr;
            return true;
        }

        return false;
    }

    //when root has a single child, YOU (means YOU means YOU means NOT me, but YOU means STUDENT) has to do it
    // single child can be RIGHT or LEFT

    else
    {
		BSTNode*p = root;
		BSTNode*c = root;

        while(1)
        {
            if (c->data == value)
                break;

            if (value <c->data) //left
            {
                p = c;
                c = c->leftChild;
            }

            else //right
            {
                p = c;
                c = c->rightChild;
            }

            if (c==nullptr)
                return false;

        }

        //cout << p->data << endl;
        //cout << c->data << endl;
        //while(1)
        //{

        //}

        //2 children case
        if (c->rightChild!=nullptr && c->leftChild!=nullptr) 
        {
            BSTNode*t = c;
            p = t; //p = t->rightChild == not good, because...
            c = t->rightChild;
            while(1)
            {
                if (c->leftChild == nullptr)
                    break;

                p = c;
                c = c->leftChild;
            }

            t->data = c->data;
            value = c->data;
        }

        if (c->leftChild == nullptr && c->rightChild == nullptr) //leaf node
        {
            if (c->data < p->data) // left child of your parent
            {
                delete c;
                c = nullptr;
                p->leftChild = nullptr;

            }

            else    // right child of your parent
            {
                delete c;
                c = nullptr;
                p->rightChild = nullptr;
            }

            return true;
        }

        else if (c->rightChild == nullptr && c->leftChild !=nullptr) //single child case 1
        {
             if (c->data < p->data) // left child of your parent
            {
               
                p->leftChild = c->leftChild;
                delete c;
                c = nullptr;
            }

            else    // right child of your parent
            {
                p->rightChild = c->leftChild;
                delete c;
                c = nullptr;
            }

            return true;
        }

        else if (c->rightChild != nullptr && c->leftChild ==nullptr) //single child case 2
        {
            if (c->data < p->data) // left child of your parent
            {
               
                p->leftChild = c->rightChild;
                delete c;
                c = nullptr;
            }

            else    // right child of your parent
            {
                p->rightChild = c->rightChild;
                delete c;
                c = nullptr;
            }

            return true;
        }
    }


}
bool BST::isEmpty()
{
    return root == nullptr;
}
void BST::POSTORDER(BSTNode*p)
{
    if (p!=nullptr)
    {
        
        POSTORDER(p->leftChild);   //L
        POSTORDER(p->rightChild);  //R
		p->data.display();
		cout << '\n'; //N
	}
}
void BST::postorder()
{
    if (root == nullptr)
        cout << "Tree is empty" << endl;

    else
        POSTORDER(root);
}
void BST::PREORDER(BSTNode*p)
{
    if (p!=nullptr)
    {
		p->data.display();
//		cout << '\n'; //N
		PREORDER(p->leftChild);   //L
        PREORDER(p->rightChild);  //R
    }
}
void BST::preorder()
{
    if (root == nullptr)
        cout << "Tree is empty" << endl;

    else
        PREORDER(root);
}
void BST::INORDER2(BSTNode*p)
{
    if (p!=nullptr)
    {
        INORDER2(p->rightChild); //R
		p->data.display();
		cout << '\n'; //N
		INORDER2(p->leftChild);  //L
    }
}
void BST::inorder2()
{
    if (root == nullptr)
        cout << "Tree is empty" << endl;

    else
        INORDER2(root);
}
void BST::INORDER(BSTNode*p)
{
    if (p!=nullptr)
    {
        INORDER(p->leftChild);   //L
		p->data.display(); 
		cout << '\n'; //N
        INORDER(p->rightChild);  //R
    }
}
void BST::inorder()
{
    if (root == nullptr)
        cout << "Tree is empty" << endl;

    else
        INORDER(root);
}
void BST::insert(Account value)
{
	BSTNode*nn = new BSTNode;
    nn->data = value;
    nn->leftChild = nullptr;
    nn->rightChild = nullptr;

    if (root == nullptr)
        root = nn;

    else
    {
		BSTNode*t = root;

        while(1)
        {
            if (value < t->data) //smaller
            {
                if (t->leftChild == nullptr)
                {

                     t->leftChild = nn;
                    break;
                }

                else
                    t = t->leftChild;
            }

            else //greater or equal (right case)
            {
                if (t->rightChild == nullptr)
                {
                    t->rightChild = nn;
                    break;
                }

                else
                    t = t->rightChild;
            }
        }
    }

}
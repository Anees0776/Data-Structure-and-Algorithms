#include <string>
using namespace std;
void printColorText2(int text, int fgColor, int bgColor) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	int colorCode = (bgColor << 4) | fgColor;
	SetConsoleTextAttribute(hConsole, colorCode);

	cout << text;

	SetConsoleTextAttribute(hConsole, 7);
}

class Account {
public:
	string name;
	int ball;
	int accno;
	int code;
	Account() : name(""), ball(0), accno(0),code(0) {}
	Account(string n, int b, int a) : name(n), ball(b), accno(a) {}
	friend Account operator+(const Account& a1, const Account& a2);
	bool operator==(const Account& other) const {
		return accno == other.accno;
	}

	bool operator<(const Account& other) const {
		return ball < other.ball;
	}

	bool operator>(const Account& other) const {
		return ball > other.ball;
	}
	
void display(){
		if (code==-1){
			cout << name << "    " << "Deposited" << "    ";
			printColorText2(ball, 10, 16); cout << "PKR" << endl;//text color, bg color/*", Account No: " << accno*/;
		}
		else if (code == +1){
			cout << name << "    " << "Withdrawn" << "    ";
			printColorText2(ball, 4, 16); cout << "PKR" << endl; //text color, bg color/*", Account No: " << accno*/;
		}
	}
	void Wdisplay(){
		cout << name << "    " << "Withdrawn" << "    " << ball<<"PKR"/*", Account No: " << accno*/;
	}
	friend ostream& operator<<(ostream& out, const Account& acc) {
		if (acc.name != ""){
			if (acc.name.size()>=9){
				out << "Date: " << acc.name << "          Amount: " << acc.ball << " PKR"<<endl;
			}
		}
		return out;
	}
};
Account operator+(const Account& a1, const Account& a2) {
	Account result = a1;
	result.ball += a2.ball;
	return result;
}
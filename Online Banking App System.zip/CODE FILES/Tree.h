#include <iostream>
#include "Node1.h"
using namespace std;
struct MonthNode {
	string month;
	int totalAmount;
	MonthNode* left;
	MonthNode* right;
};


class Tree
{
protected:
	BSTNode* root;
public:
    Tree();
	virtual void insert(Account) = 0;
    virtual void inorder() = 0;
    virtual void preorder() = 0;
    virtual void postorder() = 0;
    virtual bool isEmpty() = 0;
    
	virtual bool deleteNode(Account) = 0;
    
    //virtual bool search(int) = 0;

};

Tree::Tree()
{
    root = nullptr;
}
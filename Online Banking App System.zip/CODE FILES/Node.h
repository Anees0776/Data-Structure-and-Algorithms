#include "Account.h"

struct Node {
	Account data;
	Node* next;
	Node* prev;
};

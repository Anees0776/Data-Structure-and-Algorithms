#include<iostream>
#include<fstream>
using namespace std;

class Transaction
{
private:
	string date;
	string description;
	string refNo;
	string withdrawal;
	string deposit;
	string balance;
	Transaction* next;

	friend class Passbook;

public:
	Transaction(string d, string desc, string r, string w, string dep, string bal)
	{
		date = d;
		description = desc;
		refNo = r;
		withdrawal = w;
		deposit = d;
		balance = bal;
		next = nullptr;
	}
};

class Passbook
{
private:
	Transaction* head;

	void printAligned(string text, int width)
	{
		cout << text;
		for (int i = text.length(); i < width; i++)
		{
			cout << " ";
		}
	}

	string covertFloattoString(float num)
	{
		int wholePart = (int)num;
		int decimalPart = (int)((num - wholePart) * 100 + 0.5);

		char result[20];
		int index = 0;

		int temp = wholePart;
		char revWhole[10];
		int i = 0;

		if (temp == 0)
		{
			revWhole[i++] = '0';
		}
		while (temp > 0)
		{
			revWhole[i++] = (temp % 10) + '0';
			temp /= 10;
		}

		for (int j = i - 1; j >= 0; j--)
		{
			result[index++] = revWhole[j];
		}
		result[index++] = '.';

		if (decimalPart < 10)
		{
			result[index++] = '0';
			result[index++] = (decimalPart % 10) + '0';
		}
		else
		{
			result[index++] = (decimalPart / 10) + '0';
			result[index++] = (decimalPart % 10) + '0';
		}
		result[index] = '\0';
		return string(result);
	}

	string generateRefNo()
	{
		int number = 1000 + rand() % 9000;
		char buffer[10];
		int index = 0;
		char rev[10];

		int i = 0;
		while (number > 0)
		{
			rev[i++] = (number % 10) + '0';
			number /= 10;
		}

		for (int j = i - 1; j >= 0; j--)
		{
			buffer[index++] = rev[j];
		}

		buffer[index] = '\0';
		return string(buffer);
	}

public:
	Passbook()
	{
		head = nullptr;
	}

	void loadFile(string username)
	{
		string filename = username + "TransactionHistory.txt";
		ifstream fin(filename);

		if (!fin.is_open())
		{
			cout << "Error: couldn't find file for user: " << username << endl;
			return;
		}

		char type[5], date[15], amount[20];
		float balance = 0;

		while (fin.getline(type, 5, ','))
		{
			fin.getline(date, 15, ',');
			fin.getline(amount, 20);

			float amountt = atof(amount);
			string withdrawal = "-", deposit = "-", description;
			string ref = generateRefNo();

			if (string(type) == "-1")
			{
				withdrawal = covertFloattoString(amountt);
				deposit = "+";
				description = "Amount Withdrawn from Amount ";
				balance -= amountt;
			}
			else
			{
				withdrawal = "-";
				deposit = covertFloattoString(amountt);
				description = "Amount deposits into Account ";
				balance += amountt;
			}

			string balanceStr = covertFloattoString(balance);

			Transaction* newNode = new Transaction(date, description, ref, withdrawal, deposit, balanceStr);

			if (!head)
			{
				head = newNode;
			}
			else
			{
				Transaction* temp = head;
				while (temp->next != nullptr)
				{
					temp = temp->next;
				}
				temp->next = newNode;
			}
		}
		fin.close();
	}

	void displayPassbook()
	{
		if (head == nullptr)
		{
			cout << "No Transaction to display " << endl;
			return;
		}
		cout << "\n";
		printAligned("Date", 15);
		printAligned("Description", 35);
		printAligned("Ref.", 12);
		printAligned("Withdrawals", 17);
		printAligned("Deposits", 14);
		printAligned("Balance", 12);
		cout << "\n";

		Transaction* temp = head;
		while (temp)
		{
			printAligned(temp->date, 15);
			printAligned(temp->description, 35);
			printAligned(temp->refNo, 12);
			printAligned(temp->withdrawal, 17);
			temp->withdrawal =temp->withdrawal + "21";
			printAligned(temp->withdrawal+"31", 14);
			printAligned(temp->balance, 12);
			cout << endl;

			temp = temp->next;
		}
	}
};
#include <iostream>
#include <string>
using namespace std;

class Account {
private:
    int id;
    string name;
    float balance;
    int pin;

public:
    Account() {
        id = 0;
        name = "";
        balance = 0.0f;
        pin = 0;
    }

    Account(int i, string n, float b, int p) {
        id = i;
        name = n;
        balance = b;
        pin = p;
    }

    int getId() const { return id; }
    string getName() const { return name; }
    float getBalance() const { return balance; }
    int getPin() const { return pin; }

    void setId(int i) { id = i; }
    void setName(string n) { name = n; }
    void setBalance(float b) { balance = b; }
    void setPin(int p) { pin = p; }

    bool operator==(const Account& other) const {
        return id == other.id; // comparison based on ID
    }

    friend ostream& operator<<(ostream& out, const Account& Account) {
        out << "[ID: " << Account.id << ", Name: " << Account.name << ", Balance: " << Account.balance << "]";
        return out;
    }
};

class Transaction {
private:
    string type;
    int fromID;
    int toID;
    float amount;

public:
    Transaction() {
        type = "";
        fromID = toID = 0;
        amount = 0.0f;
    }

    Transaction(string t, int from, int to, float amt) {
        type = t;
        fromID = from;
        toID = to;
        amount = amt;
    }

    string getType() const { return type; }
    int getFromID() const { return fromID; }
    int getToID() const { return toID; }
    float getAmount() const { return amount; }

    friend ostream& operator<<(ostream& out, const Transaction& t) {
        out << "[Type: " << t.type << ", From: " << t.fromID
            << ", To: " << t.toID << ", Amount: " << t.amount << "]";
        return out;
    }
};

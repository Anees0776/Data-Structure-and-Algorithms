﻿#include <iostream>
#include <fstream>
#include<string>
using namespace std;

struct LoanInfo {
	string id;
	string user;
	float amount;
	float rate;
	string date;
};

class MyLoanManager {
private:
	static const int maxSize = 100;
	LoanInfo loanList[maxSize];
	string loanQueue[maxSize];
	int front, rear, total;

public:
	MyLoanManager() {
		total = 0;
		front = 0;
		rear = 0;
	}

	// ---------------- QUEUE METHODS ----------------
	void enqueueLoanID(string id) {
		if (rear == maxSize) {
			cout << "Loan Queue Overflow!" << endl;
			return;
		}
		loanQueue[rear++] = id;
	}

	string dequeueLoanID() {
		if (isQueueEmpty()) return "";
		return loanQueue[front++];
	}

	bool isQueueEmpty() {
		return front == rear;
	}

	string peekLoanID() {
		if (isQueueEmpty()) return "";
		return loanQueue[front];
	}

	// ---------------- APPLICATION LOGIC ----------------
	void applyForLoan(string id, string username, float amt, float rate, string date) {
		if (total >= maxSize) {
			cout << "Loan storage full!" << endl;
			return;
		}

		loanList[total] = { id, username, amt, rate, date };
		enqueueLoanID(id);
		total++;

		cout << "Loan Application Submitted Successfully for " << username << endl;
	}

	int findLoanByID(string id, int i = 0) {
		if (i >= total) return -1;
		if (loanList[i].id == id) return i;
		return findLoanByID(id, i + 1);
	}

	float sumUserDeposits(ifstream& file) {
		float x;
		if (!(file >> x)) return 0;
		return x + sumUserDeposits(file);
	}

	bool isEligible(string user, float requestedAmt) {
		ifstream fin(user + ".txt");
		if (!fin.is_open()) {
			cout << "No deposit record found for user: " << user << endl;
			return false;
		}
		float totalDeposits = sumUserDeposits(fin);
		fin.close();

		return totalDeposits > requestedAmt;
	}

	// ---------------- ADMIN FUNCTIONS ----------------
	void processNextLoanApproval() {
		if (isQueueEmpty()) {
			cout << "No loan applications pending." << endl;
			return;
		}

		string id = dequeueLoanID();
		int idx = findLoanByID(id);
		if (idx == -1) {
			cout << "Loan ID not found." << endl;
			return;
		}

		LoanInfo& l = loanList[idx];
		if (isEligible(l.user, l.amount)) {
			cout << "Loan Approved for " << l.user << " [Loan ID: " << l.id << "]" << endl;
		}
		else {
			cout << "Loan Rejected for " << l.user << " [Loan ID: " << l.id << "]" << endl;
		}
	}

	void rejectNextLoan() {
		if (isQueueEmpty()) {
			cout << "No loans to reject." << endl;
			return;
		}

		string id = dequeueLoanID();
		int idx = findLoanByID(id);
		if (idx == -1) {
			cout << "Loan ID not found." << endl;
			return;
		}

		cout << "Loan Rejected: " << id << " for user " << loanList[idx].user << endl;
	}

	void showNextLoan() {
		if (isQueueEmpty()) {
			cout << "No pending loans." << endl;
			return;
		}

		string id = peekLoanID();
		int idx = findLoanByID(id);

		if (idx == -1) {
			cout << "Loan ID not found in records." << endl;
			return;
		}

		LoanInfo& l = loanList[idx];
		cout << "\nNext Pending Loan:\n";
		cout << "Loan ID: " << l.id << ", User: " << l.user
			<< ", Amount: " << l.amount << ", Interest Rate: " << l.rate
			<< ", Date: " << l.date << endl;
	}
};

#include "Stack.h"

// ------- Stack Implementation -------- //


class myStack :public Stack
{
public:
	myStack(int size = 10);
	bool isEmpty();
	bool isFull();
	void Push(Transaction value);
	Transaction Pop();
	Transaction Top();
	void display() const;
};


myStack::myStack(int size) :Stack(size)
{

}

bool myStack::isEmpty()
{
	return Stack::currentSize == 0;
}

bool myStack::isFull()
{
	return Stack::currentSize == Stack::maxSize;
}


void myStack::Push(Transaction value)
{
	if (isFull())
	{
		cout << "Stack is Full.\n";
	}
	else
	{
		Stack::arr[Stack::currentSize] = value;
		Stack::currentSize++;
	}
}


Transaction myStack::Pop()
{
	if (isEmpty())
	{
		cout << "Stack is Empty.\n";
		return Transaction();
	}
	else
	{
		Stack::currentSize--;
		return Stack::arr[Stack::currentSize];
	}
}

Transaction myStack::Top()
{
	if (isEmpty())
	{
		cout << "Stack is Empty.\n";
		return Transaction();
	}
	else
	{
		return Stack::arr[Stack::currentSize - 1];
	}
}


void myStack::display() const
{
	cout << "\nMaximum Transactions: " << Stack::maxSize << "\n";
	cout << "Current Transactrions: " << Stack::currentSize << "\n\n";

	for (int i = 0; i < Stack::currentSize; i++)
	{
		cout << i << ". " << Stack::arr[i] << "\n";
	}
}

#include "LinkedList.h"

class myDLL : public LinkedList {
public:
	void insertAtTail(Account);
	void insertAtHead(Account);
	void displayFromHead();
	void displayFromTail();
	bool isEmpty();
	Account deleteFromTail();
	Account deleteFromHead();
	bool deleteValue(Account);
	bool search(Account);
	void insertSorted(Account);
	void displayFromTail2(int n);
};
	// ================= Implementation =================

	void myDLL::insertAtTail(Account value) {
		Node* nn = new Node{ value, nullptr, nullptr };
		if (isEmpty()) {
			head = tail = nn;
		}
		else {
			tail->next = nn;
			nn->prev = tail;
			tail = nn;
		}
	}

	void myDLL::insertAtHead(Account value) {
		Node* nn = new Node{ value, nullptr, nullptr };
		if (isEmpty()) {
			head = tail = nn;
		}
		else {
			nn->next = head;
			head->prev = nn;
			head = nn;
		}
	}

	bool myDLL::isEmpty() {
		return head == nullptr && tail == nullptr;
	}

	Account myDLL::deleteFromHead() {
		if (isEmpty()) return Account();

		Account returningValue = head->data;

		if (head == tail) {
			delete head;
			head = tail = nullptr;
		}
		else {
			Node* temp = head;
			head = head->next;
			head->prev = nullptr;
			delete temp;
		}

		return returningValue;
	}

	Account myDLL::deleteFromTail() {
		if (isEmpty()) return Account();

		Account returningValue = tail->data;

		if (head == tail) {
			delete tail;
			head = tail = nullptr;
		}
		else {
			Node* temp = tail;
			tail = tail->prev;
			tail->next = nullptr;
			delete temp;
		}

		return returningValue;
	}

	bool myDLL::deleteValue(Account value) {
		if (isEmpty()) return false;

		if (head == tail) {
			if (head->data == value) {
				delete head;
				head = tail = nullptr;
				return true;
			}
			return false;
		}

		if (head->data == value) {
			deleteFromHead();
			return true;
		}

		if (tail->data == value) {
			deleteFromTail();
			return true;
		}

		Node* temp = head->next;

		while (temp != nullptr) {
			if (temp->data == value) {
				temp->prev->next = temp->next;
				if (temp->next)
					temp->next->prev = temp->prev;
				delete temp;
				return true;
			}
			temp = temp->next;
		}

		return false;
	}

	void myDLL::displayFromHead() {
		if (isEmpty()) {
			cout << "LL is empty" << endl;
			return;
		}

		Node* temp = head;
		while (temp != nullptr) {
			cout<<temp->data; 
			temp = temp->next;
		}
	}

	void myDLL::displayFromTail() {
		if (isEmpty()) {
			cout << "LL is empty" << endl;
			return;
		}

		Node* temp = tail;
		while (temp != nullptr) {
			cout << temp->data;
			temp = temp->prev;
		}
	}
	void myDLL::displayFromTail2(int n) {
		if (isEmpty()) {
			cout << "LL is empty" << endl;
			return;
		}

		Node* temp = tail; int i = 0;
		while (temp != nullptr) {
			if (i < n){
				cout << temp->data.name<< endl;
				cout << temp->data.ball << endl;
			}
			i++;
			temp = temp->prev;
		}
	}
	bool myDLL::search(Account value) {
		Node* temp = head;
		while (temp != nullptr) {
			if (temp->data == value)
				return true;
			temp = temp->next;
		}
		return false;
	}

	void myDLL::insertSorted(Account value) {
		Node* nn = new Node;
		nn->data = value;
		nn->next = nullptr;
		nn->prev = nullptr;

		// Case 1: Empty list
		if (head == nullptr) {
			head = tail = nn;
			return;
		}

		// Case 2: Insert at head
		if (value < head->data) {
			nn->next = head;
			head->prev = nn;
			head = nn;
			return;
		}

		// Case 3: Insert at tail
		if (value > tail->data) {
			nn->prev = tail;
			tail->next = nn;
			tail = nn;
			return;
		}

		// Case 4: Insert in middle
		Node* temp = head;
		while (temp->next && temp->next->data < value) {
			temp = temp->next;
		}

		// Insert after temp
		nn->next = temp->next;
		nn->prev = temp;

		if (temp->next) {
			temp->next->prev = nn;
		}
		temp->next = nn;
	}